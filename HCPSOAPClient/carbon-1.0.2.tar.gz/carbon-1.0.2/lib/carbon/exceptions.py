class CarbonConfigException(Exception):
    """Raised when a carbon daemon is improperly configured"""
