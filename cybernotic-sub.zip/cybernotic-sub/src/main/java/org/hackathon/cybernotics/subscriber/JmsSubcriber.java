package org.hackathon.cybernotics.subscriber;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class JmsSubcriber {
	
	@JmsListener(destination = "${spring.activemq.topic}")
	public void receive(String msg){
		System.out.println("Recieved Message: " + msg);
	}
}
